# automate-selenium
As a Full Stack Developer, you have to build an automation script that automated the basic functionalities like registration and login.
